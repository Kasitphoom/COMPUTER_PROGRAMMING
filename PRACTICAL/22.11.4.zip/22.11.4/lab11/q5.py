s = set([1, 2, 3])

def power(s):
    power_set = [set()]
    for element in s:
        for subset in power_set:
            power_set = power_set + [subset | set([element])]
    return power_set

print(power(s))